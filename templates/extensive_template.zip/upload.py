
# Imports
from continuous_delivery.github_config import github_config
from continuous_delivery.pmc_config import pmc_config
from stewbeet.continuous_delivery import load_credentials, upload_to_github, upload_to_pmc

# Get credentials
credentials: dict[str, str] = load_credentials("~/stewbeet/credentials.yml")

## Uploads
# Upload to GitHub
changelog: str = upload_to_github(credentials, github_config)

# Upload to PlanetMinecraft
upload_to_pmc(pmc_config, changelog)

