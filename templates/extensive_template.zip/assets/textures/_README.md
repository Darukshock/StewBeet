
## Textures folder
Every .png file and .png.mcmeta files in the folder will be recognized by the build system.
You can pack up textures in folders if you want.

