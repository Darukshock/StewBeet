
## Sounds folder
Every .ogg file in the folder will be recognized by the build system ONLY IF you call the 'generate_custom_records()' function available in the definitions_helper file.
Files in subfolders will be ignored!

