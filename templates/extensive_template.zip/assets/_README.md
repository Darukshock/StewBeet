
## Assets folder
This folder should contains sounds and textures folders along with "original_icon.png" that will be used as the icon for datapack and resource pack.

