
## merge/datapack folder
Every file and subfolders will be merged to the build datapack folder.

